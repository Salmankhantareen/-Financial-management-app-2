import { DB } from './database.js';
import { Auth } from './auth.js';
import { toast } from './notifications.js';

const form = document.querySelector('#login-form');
const alertBox = document.querySelector('#login-alert');

function redirectFor(user) { window.location.href = user.role === 'Project User' ? 'user.html' : 'admin.html'; }
function showError(message) { alertBox.textContent = message; alertBox.classList.remove('d-none'); }
function clearError() { alertBox.textContent = ''; alertBox.classList.add('d-none'); }
function validate() {
  let valid = true;
  form.querySelectorAll('[required]').forEach((field) => { const error = field.closest('.input-wrap')?.querySelector('.field-error'); if (!field.value.trim()) { valid = false; field.classList.add('is-invalid'); if (error) error.textContent = 'This field is required.'; } else { field.classList.remove('is-invalid'); if (error) error.textContent = ''; } });
  return valid;
}

(async function boot() {
  try {
    await DB.init();
    if (Auth.isAuthenticated()) redirectFor(Auth.currentUser());
  } catch (error) { showError(`Local database could not start: ${error.message}`); }
}());

form?.addEventListener('submit', async (event) => {
  event.preventDefault(); clearError(); if (!validate()) return;
  const submit = form.querySelector('button[type="submit"]'); const original = submit.innerHTML; submit.disabled = true; submit.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Signing in…';
  try { const user = await Auth.login(form.identity.value, form.password.value, form.remember.checked); toast('Welcome back', `${user.name} · ${user.role}`, 'success', 1800); window.setTimeout(() => redirectFor(user), 450); } catch (error) { showError(error.message); submit.disabled = false; submit.innerHTML = original; }
});

document.querySelector('#toggle-password')?.addEventListener('click', (event) => { const input = document.querySelector('#password'); const showing = input.type === 'text'; input.type = showing ? 'password' : 'text'; event.currentTarget.innerHTML = `<i class="bi bi-eye${showing ? '' : '-slash'}"></i>`; event.currentTarget.setAttribute('aria-label', showing ? 'Show password' : 'Hide password'); });
document.querySelectorAll('.demo-account').forEach((button) => button.addEventListener('click', () => { document.querySelector('#identity').value = button.dataset.identity; document.querySelector('#password').value = button.dataset.password; clearError(); form.requestSubmit(); }));
document.querySelector('#forgot-password')?.addEventListener('click', () => window.bootstrap && bootstrap.Modal.getOrCreateInstance(document.querySelector('#forgot-modal')).show());
document.querySelector('#request-reset')?.addEventListener('click', () => { const email = document.querySelector('#reset-identity').value.trim(); if (!email) { toast('Email required', 'Enter the account email to create a support request.', 'warning'); return; } bootstrap.Modal.getInstance(document.querySelector('#forgot-modal'))?.hide(); toast('Support request created', 'An administrator would handle this request in a connected authentication service.', 'info'); });
