import { DB, getSettings, uid } from './database.js';
import { Auth } from './auth.js';
import { Notifications, refreshNotificationPanel, toast, relativeTime } from './notifications.js';
import { formatMoney, formatNumber, formatDate, createAuditLog } from './accounting.js';

export const NAV_GROUPS = [
  { key: 'overview', label: 'Overview', items: [{ key: 'dashboard', label: 'Dashboard', icon: 'bi-grid-1x2-fill', permission: ['dashboard', 'view'] }] },
  { key: 'people', label: 'People & Partners', items: [
    { key: 'users', label: 'User Management', icon: 'bi-people', permission: ['users', 'view'] },
    { key: 'employees', label: 'Employees', icon: 'bi-person-badge', permission: ['employees', 'view'] },
    { key: 'suppliers', label: 'Suppliers', icon: 'bi-truck', permission: ['suppliers', 'view'] },
    { key: 'customers', label: 'Customers', icon: 'bi-person-lines-fill', permission: ['customers', 'view'] }
  ] },
  { key: 'operations', label: 'Operations', items: [
    { key: 'projects', label: 'Projects', icon: 'bi-buildings', permission: ['projects', 'view'] },
    { key: 'cost-centers', label: 'Cost Centers', icon: 'bi-diagram-3', permission: ['costCenters', 'view'] },
    { key: 'procurement', label: 'Procurement', icon: 'bi-cart-check', permission: ['inventory', 'view'] },
    { key: 'budgets', label: 'Budget Management', icon: 'bi-pie-chart', permission: ['budgets', 'view'] }
  ] },
  { key: 'accounting', label: 'Accounting & Treasury', items: [
    { key: 'transactions', label: 'Transactions', icon: 'bi-arrow-left-right', permission: ['transactions', 'view'] },
    { key: 'vouchers', label: 'Transaction Vouchers', icon: 'bi-receipt', permission: ['transactions', 'view'] },
    { key: 'accounts', label: 'Chart of Accounts', icon: 'bi-list-columns-reverse', permission: ['accounts', 'view'] },
    { key: 'ledger', label: 'General Ledger', icon: 'bi-journal-text', permission: ['ledger', 'view'] },
    { key: 'journals', label: 'Journal Entries', icon: 'bi-journal-plus', permission: ['journals', 'view'] },
    { key: 'cash-bank', label: 'Cash & Bank', icon: 'bi-bank', permission: ['cashBank', 'view'] },
    { key: 'currencies', label: 'Currency Exchange', icon: 'bi-currency-exchange', permission: ['currencies', 'view'] },
    { key: 'assets', label: 'Fixed Assets', icon: 'bi-truck-front', permission: ['assets', 'view'] },
    { key: 'inventory', label: 'Inventory', icon: 'bi-box-seam', permission: ['inventory', 'view'] },
    { key: 'revenue', label: 'Revenue', icon: 'bi-graph-up-arrow', permission: ['revenue', 'view'] },
    { key: 'expenses', label: 'Expenses', icon: 'bi-graph-down-arrow', permission: ['expenses', 'view'] }
  ] },
  { key: 'reports', label: 'Reports & Controls', items: [
    { key: 'profit-loss', label: 'Profit & Loss', icon: 'bi-bar-chart-line', permission: ['reports', 'view'] },
    { key: 'cash-flow', label: 'Cash Flow', icon: 'bi-water', permission: ['reports', 'view'] },
    { key: 'cash-flow-in', label: 'Cash Flow In', icon: 'bi-box-arrow-in-down-left', permission: ['reports', 'view'] },
    { key: 'cash-flow-out', label: 'Cash Flow Out', icon: 'bi-box-arrow-up-right', permission: ['reports', 'view'] },
    { key: 'payments', label: 'Payments', icon: 'bi-wallet2', permission: ['payments', 'view'] },
    { key: 'receivables', label: 'Receivables', icon: 'bi-arrow-down-circle', permission: ['receivables', 'view'] },
    { key: 'payables', label: 'Payables', icon: 'bi-arrow-up-circle', permission: ['payables', 'view'] },
    { key: 'approvals', label: 'Approvals', icon: 'bi-check2-square', permission: ['approvals', 'view'] },
    { key: 'reports', label: 'Financial Reports', icon: 'bi-file-earmark-bar-graph', permission: ['reports', 'view'] }
  ] },
  { key: 'governance', label: 'Governance', items: [
    { key: 'audit', label: 'Audit Logs', icon: 'bi-shield-check', permission: ['audit', 'view'] },
    { key: 'notifications', label: 'Notifications', icon: 'bi-bell', permission: ['notifications', 'view'] },
    { key: 'settings', label: 'System Settings', icon: 'bi-sliders2', permission: ['settings', 'view'] }
  ] }
];

const PAGE_LABELS = Object.fromEntries(NAV_GROUPS.flatMap((group) => group.items.map((item) => [item.key, item.label])));
const escapeHtml = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));
export { escapeHtml };

export function appPageLabel(key) { return PAGE_LABELS[key] || key; }
export function statusBadge(status = '') { const className = `status-${String(status).toLowerCase().replace(/\s+/g, '-')}`; return `<span class="badge-status ${className}">${escapeHtml(status)}</span>`; }
export function initials(name = '') { return Auth.initials(name); }
export function iconButton(icon, title, action = '', extra = '') { return `<button class="table-action ${extra}" type="button" title="${escapeHtml(title)}" data-action="${escapeHtml(action)}"><i class="bi ${icon}"></i></button>`; }

function permitted(item) { return !item.permission || Auth.can(item.permission[0], item.permission[1], { silent: true }); }
function visibleGroups() { return NAV_GROUPS.map((group) => ({ ...group, items: group.items.filter(permitted) })).filter((group) => group.items.length); }

export async function createAppShell({ workspace = 'admin', user, onNavigate }) {
  const sidebar = document.querySelector('#sidebar'); const topbar = document.querySelector('#topbar');
  if (!sidebar || !topbar) throw new Error('App shell containers are missing.');
  const settings = await getSettings();
  const groups = visibleGroups();
  sidebar.innerHTML = `<div class="sidebar-brand"><a href="#" class="brand-lockup" id="brand-home"><div class="brand-mark"><span>${escapeHtml(settings.logoText || 'HA')}</span></div><div><strong>HILAL AMIN</strong><small>CONSTRUCTION COMPANY</small></div></a></div><div class="sidebar-scroll">${groups.map((group, index) => `<div class="nav-section ${localStorage.getItem(`hacfm_nav_${group.key}`) === 'false' && index >= 2 ? 'collapsed' : ''}" data-nav-group="${group.key}"><button class="nav-section-label nav-section-toggle" type="button" aria-expanded="${localStorage.getItem(`hacfm_nav_${group.key}`) === 'false' && index >= 2 ? 'false' : 'true'}"><span>${escapeHtml(group.label)}</span><i class="bi bi-chevron-down"></i></button><ul class="sidebar-nav">${group.items.map((item) => `<li><a class="nav-link" href="#${item.key}" data-page="${item.key}" title="${escapeHtml(item.label)}"><i class="bi ${item.icon}"></i><span>${escapeHtml(item.label)}</span></a></li>`).join('')}</ul></div>`).join('')}</div><div class="sidebar-footer"><div class="sidebar-status"><i></i><span>Local workspace online</span></div></div>`;
  topbar.innerHTML = `<button class="topbar-menu" id="mobile-menu" type="button" aria-label="Open navigation"><i class="bi bi-list"></i></button><div class="breadcrumbs"><span>Workspace</span><i class="bi bi-chevron-right"></i><strong id="breadcrumb-current">Dashboard</strong></div><div class="topbar-search" role="search"><i class="bi bi-search"></i><input id="global-search" type="search" placeholder="Search records…" autocomplete="off"><kbd>⌘ K</kbd></div><div class="topbar-actions"><select id="global-currency" class="currency-select" aria-label="Reporting currency"><option value="PKR">PKR · Rupee</option><option value="USD">USD · Dollar</option><option value="AFA">AFA · Afghani</option></select><button class="topbar-icon" id="notification-toggle" type="button" title="Notifications"><i class="bi bi-bell"></i><span class="notification-count d-none" id="notification-count">0</span></button><div class="dropdown"><button class="profile-trigger" type="button" data-bs-toggle="dropdown" aria-expanded="false"><span class="avatar">${initials(user?.name)}</span><span class="profile-copy"><strong>${escapeHtml(user?.name || 'Workspace user')}</strong><small>${escapeHtml(user?.role || workspace)}</small></span><i class="bi bi-chevron-down"></i></button><ul class="dropdown-menu dropdown-menu-end profile-menu"><li class="profile-menu-head"><strong>${escapeHtml(user?.name || 'Workspace user')}</strong><small>${escapeHtml(user?.email || '')}</small></li><li><button class="dropdown-item" type="button" data-profile-action="profile"><i class="bi bi-person me-2"></i> My profile</button></li><li><button class="dropdown-item" type="button" data-profile-action="theme"><i class="bi bi-circle-half me-2"></i> Toggle theme</button></li><li><hr class="dropdown-divider"></li><li><button class="dropdown-item text-danger" type="button" data-profile-action="logout"><i class="bi bi-box-arrow-right me-2"></i> Sign out</button></li></ul></div></div>`;
  document.body.dataset.workspace = workspace;
  setTheme(localStorage.getItem('hacfm_theme') || settings.theme || 'dark');
  bindShellEvents({ onNavigate, workspace });
  await updateNotificationCount();
  window.addEventListener('hacfm:notifications-changed', updateNotificationCount);
  window.addEventListener('hacfm:permission-denied', () => toast('Access restricted', 'Your role does not allow that action.', 'warning'));
  return { settings, groups };
}

function bindShellEvents({ onNavigate, workspace }) {
  const sidebar = document.querySelector('#sidebar'); const scrim = document.querySelector('#sidebar-scrim');
  sidebar.querySelector('#brand-home')?.addEventListener('click', (event) => { event.preventDefault(); navigateTo('dashboard', onNavigate); });
  sidebar.querySelectorAll('.nav-link').forEach((link) => link.addEventListener('click', (event) => { event.preventDefault(); const page = link.dataset.page; navigateTo(page, onNavigate); closeMobileNav(); }));
  sidebar.querySelectorAll('.nav-section-toggle').forEach((button) => button.addEventListener('click', () => { const group = button.closest('.nav-section'); const open = group.classList.toggle('collapsed') === false; button.setAttribute('aria-expanded', String(open)); localStorage.setItem(`hacfm_nav_${group.dataset.navGroup}`, String(open)); }));
  document.querySelector('#mobile-menu')?.addEventListener('click', () => { sidebar.classList.add('open'); scrim?.classList.add('open'); });
  scrim?.addEventListener('click', closeMobileNav);
  document.querySelector('#notification-toggle')?.addEventListener('click', async (event) => { event.stopPropagation(); const panel = document.querySelector('#notification-panel') || (await refreshNotificationPanel()).panel; if (!panel.innerHTML) await refreshNotificationPanel(); panel.classList.toggle('open'); });
  document.addEventListener('click', (event) => { const panel = document.querySelector('#notification-panel'); if (panel?.classList.contains('open') && !panel.contains(event.target) && !event.target.closest('#notification-toggle')) panel.classList.remove('open'); });
  const currency = document.querySelector('#global-currency');
  if (currency) { currency.value = localStorage.getItem('hacfm_reporting_currency') || 'PKR'; currency.addEventListener('change', () => { localStorage.setItem('hacfm_reporting_currency', currency.value); toast('Reporting currency updated', `New summaries will be labelled ${currency.value}; historical base values remain stored in PKR.`, 'info'); }); }
  document.querySelector('#global-search')?.addEventListener('keydown', (event) => { if (event.key === 'Enter') { const term = event.currentTarget.value.trim(); if (term) navigateTo('transactions', onNavigate, { search: term }); } });
  document.addEventListener('keydown', (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') { event.preventDefault(); document.querySelector('#global-search')?.focus(); } });
  document.querySelectorAll('[data-profile-action]').forEach((button) => button.addEventListener('click', () => handleProfileAction(button.dataset.profileAction, onNavigate, workspace)));
}

function closeMobileNav() { document.querySelector('#sidebar')?.classList.remove('open'); document.querySelector('#sidebar-scrim')?.classList.remove('open'); }
async function handleProfileAction(action, onNavigate, workspace) {
  if (action === 'logout') { await Auth.logout(); return; }
  if (action === 'theme') { setTheme(document.body.classList.contains('light-theme') ? 'dark' : 'light'); return; }
  if (action === 'profile') { openProfileModal(); }
}
function setTheme(theme) { document.body.classList.toggle('light-theme', theme === 'light'); localStorage.setItem('hacfm_theme', theme); }
export function navigateTo(page, onNavigate, options = {}) { setActivePage(page); onNavigate?.(page, options); }
export function setActivePage(page) { document.querySelectorAll('.sidebar-nav .nav-link').forEach((link) => link.classList.toggle('active', link.dataset.page === page)); const label = document.querySelector('#breadcrumb-current'); if (label) label.textContent = PAGE_LABELS[page] || 'Workspace'; }
export function showAppLoader(show = true) { document.querySelector('#app-loader')?.classList.toggle('hidden', !show); }
async function updateNotificationCount() { const count = await Notifications.unreadCount(); const element = document.querySelector('#notification-count'); if (element) { element.textContent = count; element.classList.toggle('d-none', !count); } if (document.querySelector('#notification-panel')?.classList.contains('open')) await refreshNotificationPanel(); }

export function renderPageHeader({ kicker = 'FINANCIAL OPERATIONS', title, subtitle = '', actions = '' }) { return `<div class="page-header"><div><span class="page-kicker">${escapeHtml(kicker)}</span><h1 class="page-title">${escapeHtml(title)}</h1>${subtitle ? `<p class="page-subtitle">${escapeHtml(subtitle)}</p>` : ''}</div><div class="page-actions">${actions}</div></div>`; }
export function emptyState(icon = 'bi-inbox', title = 'Nothing here yet', message = 'Records will appear once they are created.', action = '') { return `<div class="empty-state"><div class="empty-icon"><i class="bi ${icon}"></i></div><h4>${escapeHtml(title)}</h4><p>${escapeHtml(message)}</p>${action}</div>`; }
export function loadingState() { return `<div class="loading-state"><div><div class="spinner-ring"></div><p class="mt-3 mb-0">Loading workspace data…</p></div></div>`; }
export function errorState(message) { return `<div class="error-state"><i class="bi bi-exclamation-octagon fs-4"></i><p class="mt-2 mb-0">${escapeHtml(message)}</p></div>`; }

export function openModal({ id = `modal-${uid('ui')}`, title, subtitle = '', body, size = '', footer = '', onShown } = {}) {
  const root = document.querySelector('#modal-root'); if (!root) return null;
  root.innerHTML = `<div class="modal fade" id="${id}" tabindex="-1" aria-hidden="true"><div class="modal-dialog modal-dialog-centered ${size}"><div class="modal-content"><div class="modal-header"><div><h5 class="modal-title">${escapeHtml(title || '')}</h5>${subtitle ? `<p class="mb-0 text-muted-light small">${escapeHtml(subtitle)}</p>` : ''}</div><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body">${body || ''}</div>${footer ? `<div class="modal-footer">${footer}</div>` : ''}</div></div></div>`;
  const node = document.getElementById(id); const modal = window.bootstrap ? bootstrap.Modal.getOrCreateInstance(node) : null; node.addEventListener('shown.bs.modal', () => onShown?.(node), { once: true }); if (modal) modal.show(); else node.classList.add('show'); node.addEventListener('hidden.bs.modal', () => { if (root.contains(node)) root.innerHTML = ''; }, { once: true }); return { node, modal, close: () => modal?.hide() };
}
export function closeModal(id) { const node = document.getElementById(id); if (!node) return; const modal = window.bootstrap ? bootstrap.Modal.getInstance(node) : null; modal?.hide(); if (!modal) node.remove(); }
export function confirmDialog({ title = 'Confirm action', message, confirmLabel = 'Confirm', danger = false } = {}) { return new Promise((resolve) => { const root = document.querySelector('#confirm-root'); const id = `confirm-${uid('ui')}`; root.innerHTML = `<div class="modal fade" id="${id}" tabindex="-1"><div class="modal-dialog modal-dialog-centered modal-sm"><div class="modal-content"><div class="modal-header"><h5 class="modal-title">${escapeHtml(title)}</h5><button class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div><div class="modal-body"><p class="mb-0 text-muted-light">${escapeHtml(message)}</p></div><div class="modal-footer"><button class="btn btn-ghost" data-choice="cancel">Cancel</button><button class="btn ${danger ? 'btn-danger-soft' : 'btn-primary'}" data-choice="confirm">${escapeHtml(confirmLabel)}</button></div></div></div></div>`; const node = document.getElementById(id); const instance = window.bootstrap ? bootstrap.Modal.getOrCreateInstance(node) : null; node.querySelectorAll('[data-choice]').forEach((button) => button.addEventListener('click', () => { resolve(button.dataset.choice === 'confirm'); instance?.hide(); })); node.addEventListener('hidden.bs.modal', () => { root.innerHTML = ''; if (!node.dataset.resolved) resolve(false); }, { once: true }); instance?.show(); }); }

export function downloadBlob(content, filename, mime = 'text/plain;charset=utf-8') { const blob = content instanceof Blob ? content : new Blob([content], { type: mime }); const url = URL.createObjectURL(blob); const link = document.createElement('a'); link.href = url; link.download = filename; document.body.appendChild(link); link.click(); link.remove(); URL.revokeObjectURL(url); }
export function downloadJSON(data, filename = 'hacfm-backup.json') { downloadBlob(JSON.stringify(data, null, 2), filename, 'application/json'); }
export function toCSV(rows = [], columns = []) { const cols = columns.length ? columns : Object.keys(rows[0] || {}).map((key) => ({ key, label: key })); const quote = (value) => `"${String(value ?? '').replace(/"/g, '""')}"`; return [cols.map((col) => quote(col.label)).join(','), ...rows.map((row) => cols.map((col) => quote(typeof col.value === 'function' ? col.value(row) : row[col.key])).join(','))].join('\n'); }
export function exportCSV(rows, columns, filename = 'export.csv') { downloadBlob(toCSV(rows, columns), filename, 'text/csv;charset=utf-8'); toast('Export ready', `${filename} downloaded.`, 'success'); }
export function printPage(title = 'Financial report') { const oldTitle = document.title; document.title = title; window.print(); document.title = oldTitle; }

export async function openProfileModal() {
  const user = Auth.currentUser(); if (!user) return;
  const employees = await DB.getAll('employees'); const employee = employees.find((row) => row.email === user.email || row.name === user.name);
  const modal = openModal({ id: 'profile-modal', title: 'My profile', subtitle: 'Profile details and development password controls', body: `<div class="row g-3"><div class="col-md-4"><div class="surface-card soft p-3 text-center h-100"><div class="avatar mx-auto mb-2" style="width:56px;height:56px;font-size:18px">${initials(user.name)}</div><strong>${escapeHtml(user.name)}</strong><span class="d-block text-muted-light small mt-1">${escapeHtml(user.role)}</span><span class="permission-chip mt-3">${escapeHtml(user.department || 'Workspace')}</span></div></div><div class="col-md-8"><div class="key-value-list"><div class="key-value-row"><span>Username</span><strong>${escapeHtml(user.username || '—')}</strong></div><div class="key-value-row"><span>Email</span><strong>${escapeHtml(user.email || '—')}</strong></div><div class="key-value-row"><span>Assigned projects</span><strong>${user.assignedProjects?.length || 0}</strong></div><div class="key-value-row"><span>Last login</span><strong>${formatDate(user.lastLogin)}</strong></div></div>${employee ? `<hr class="border-secondary opacity-25"><div class="key-value-list"><div class="key-value-row"><span>Position</span><strong>${escapeHtml(employee.position)}</strong></div><div class="key-value-row"><span>Contact</span><strong>${escapeHtml(employee.phone)}</strong></div></div>` : ''}<hr class="border-secondary opacity-25"><form id="change-password-form"><h6 class="mb-3">Change password</h6><div class="row g-2"><div class="col-md-4"><input class="form-control" type="password" name="current" placeholder="Current" required></div><div class="col-md-4"><input class="form-control" type="password" name="next" placeholder="New password" required></div><div class="col-md-4"><input class="form-control" type="password" name="confirm" placeholder="Confirm" required></div></div><button class="btn btn-ghost btn-sm mt-3" type="submit">Update password</button></form></div></div>`, footer: `<button class="btn btn-ghost" data-bs-dismiss="modal">Close</button>` });
  modal?.node.querySelector('#change-password-form')?.addEventListener('submit', async (event) => { event.preventDefault(); const data = new FormData(event.currentTarget); if (data.get('next') !== data.get('confirm')) { toast('Password not updated', 'New passwords do not match.', 'error'); return; } try { await Auth.changePassword(data.get('current'), data.get('next')); toast('Password updated', 'Development credentials were changed.', 'success'); event.currentTarget.reset(); } catch (error) { toast('Password not updated', error.message, 'error'); } });
}

export function setupResponsiveTable(root) { root.querySelectorAll('[data-table-search]').forEach((input) => input.addEventListener('input', () => { const term = input.value.toLowerCase(); const table = document.querySelector(input.dataset.tableSearch); table?.querySelectorAll('tbody tr').forEach((row) => row.classList.toggle('d-none', term && !row.textContent.toLowerCase().includes(term))); })); }
