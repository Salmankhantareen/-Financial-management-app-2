import { DB, uid } from './database.js';
import { Auth } from './auth.js';

const iconFor = (type) => ({ approval: 'bi-check2-square', budget: 'bi-graph-up-arrow', payment: 'bi-wallet2', warning: 'bi-exclamation-triangle', user: 'bi-person-plus', info: 'bi-info-circle', error: 'bi-x-circle' }[type] || 'bi-bell');
const escape = (value = '') => String(value).replace(/[&<>'"]/g, (char) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#039;', '"': '&quot;' }[char]));

export function toast(title, message = '', type = 'info', duration = 4200) {
  const host = document.querySelector('#toast-container');
  if (!host) return;
  const node = document.createElement('div');
  node.className = `toast app-toast toast-${type} show mb-2`;
  node.setAttribute('role', 'alert');
  node.innerHTML = `<div class="toast-body"><span class="toast-mark"><i class="bi ${iconFor(type)}"></i></span><span class="toast-copy"><strong>${escape(title)}</strong><span>${escape(message)}</span></span><button class="toast-close" aria-label="Close"><i class="bi bi-x"></i></button></div>`;
  node.querySelector('.toast-close').addEventListener('click', () => node.remove());
  host.appendChild(node);
  window.setTimeout(() => { node.classList.remove('show'); window.setTimeout(() => node.remove(), 220); }, duration);
}

export const Notifications = {
  async list({ unreadOnly = false, userId = null } = {}) {
    const user = Auth.currentUser();
    const rows = await DB.getAll('notifications');
    return rows.filter((row) => (!userId || row.userId === userId) && (userId || !row.userId || row.userId === user?.id) && (!unreadOnly || !row.read)).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  },
  async unreadCount() { return (await this.list({ unreadOnly: true })).length; },
  async create({ type = 'info', title, message, module = '', recordId = '', userId = null }) {
    const current = Auth.currentUser();
    const row = await DB.add('notifications', { id: uid('notif'), userId: userId || current?.id || '', type, title, message, module, recordId, read: false, createdAt: new Date().toISOString() });
    window.dispatchEvent(new CustomEvent('hacfm:notifications-changed'));
    return row;
  },
  async markRead(id) { const row = await DB.get('notifications', id); if (row) await DB.put('notifications', { ...row, read: true }); window.dispatchEvent(new CustomEvent('hacfm:notifications-changed')); },
  async markAllRead() { const rows = await this.list({ unreadOnly: true }); await Promise.all(rows.map((row) => DB.put('notifications', { ...row, read: true }))); window.dispatchEvent(new CustomEvent('hacfm:notifications-changed')); },
  iconFor,
  escape
};

export function renderNotificationPanel() {
  let panel = document.querySelector('#notification-panel');
  if (!panel) { panel = document.createElement('div'); panel.id = 'notification-panel'; panel.className = 'notification-panel'; document.body.appendChild(panel); }
  return panel;
}

export async function refreshNotificationPanel() {
  const panel = renderNotificationPanel();
  const rows = await Notifications.list();
  const unread = rows.filter((row) => !row.read).length;
  panel.innerHTML = `<div class="notification-panel-head"><strong>Notifications</strong><span>${unread ? `${unread} unread` : 'All caught up'}</span></div>${rows.slice(0, 6).map((row) => `<div class="notification-item ${row.read ? '' : 'unread'}" data-id="${row.id}" data-module="${row.module || ''}"><span class="notification-icon"><i class="bi ${iconFor(row.type)}"></i></span><span><strong>${escape(row.title)}</strong><p>${escape(row.message)}</p><time>${relativeTime(row.createdAt)}</time></span></div>`).join('') || `<div class="empty-state" style="padding:26px 15px"><div class="empty-icon"><i class="bi bi-bell-slash"></i></div><h4>No notifications</h4><p>New approvals and system events will appear here.</p></div>`}<div class="notification-panel-foot"><button class="text-button" id="mark-all-notifications" type="button">Mark all as read</button></div>`;
  panel.querySelectorAll('.notification-item').forEach((item) => item.addEventListener('click', async () => { await Notifications.markRead(item.dataset.id); item.classList.remove('unread'); }));
  panel.querySelector('#mark-all-notifications')?.addEventListener('click', () => Notifications.markAllRead());
  return { panel, unread };
}

export function relativeTime(timestamp) {
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(timestamp).getTime()) / 1000));
  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  if (seconds < 604800) return `${Math.floor(seconds / 86400)}d ago`;
  return new Date(timestamp).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
}
